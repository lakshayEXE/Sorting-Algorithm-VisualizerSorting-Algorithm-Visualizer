import React from 'react';
import './style.css';

const Footer = (props) => {
  return (
    <footer className="Footer">
      {}
    </footer>
  );
};

export default Footer;

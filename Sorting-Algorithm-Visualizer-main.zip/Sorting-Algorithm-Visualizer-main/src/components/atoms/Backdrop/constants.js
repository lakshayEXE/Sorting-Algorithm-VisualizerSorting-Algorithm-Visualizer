export const CSS_CLASSES = {
  ROOT: 'Backdrop',
  OPAQUE: 'Backdrop_opaque',
  DARK: 'Backdrop_dark',
  CLICKABLE: 'Backdrop_clickable'
};
